const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const studentrollnos = new Schema({
    sem: { 
        type: Number, 
        required: true 
    },
    year: {
         type: Number, 
        required: true 
    },
    rollnos: { 
        type : Schema.Types.Mixed, 
        required: true 
    }
  });
  
module.exports = mongoose.model('Studentrollno', studentrollnos);