const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const userSchema = new Schema({
  date:{
    type : Date,
    default:true
  },
  permissions:{
    type : Schema.Types.Mixed ,
    default:true
  }
    });

module.exports = mongoose.model('attendancepermission', userSchema);