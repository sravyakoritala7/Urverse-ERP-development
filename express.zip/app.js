var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
const { default: mongoose } = require('mongoose');
const user = require('./models/stulogin');
const faculty=require('./models/tlogin');
const attendance = require('./models/attendance');
const getdet = require('./models/getdetails');
var app = express();
var cors=require('cors');
app.use(cors());

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
mongoose.connect('mongodb://127.0.0.1/erplbrce').then(res=>{
  console.log("connected")
}).catch(err=>{
   console.log("Not connected")

})
app.use('/', indexRouter);
app.use('/users', usersRouter);
app.post('/create',function(req,res){
  let json={
    username:req.body.username,
    password:req.body.password
  }
  let u=new user(json);
  u.save().then(()=>{
    res.send("success");
  }).catch(err=>{
    res.send(err);
  })
})
app.post('/tcreate',function(req,res){
  let json={
    username:req.body.username,
    password:req.body.password
  }
  let u=new faculty(json);
  u.save().then(()=>{
    res.send("success");
  }).catch(err=>{
    res.send(err);
  })
})
app.get('/studentlogin',function(req,res){
    user.find({
      "username":req.body.username,
      "password":req.body.password
    }).then(result=>{
      if(result.length===0){
        res.send("Login failed")

      }else{
        res.send("success")
      }
    
    }).catch(err=>{console.log(err)})
})
app.get('/facultylogin',function(req,res){
  faculty.find({
    "username":req.body.username,
    "password":req.body.password
  }).then(result=>{
    if(result.length===0){
      res.send("Login failed")

    }else{
      res.send("success")
    }
  
  }).catch(err=>{console.log(err)})
})
app.post('/faculty/getData',function(req,res){
    const sem=req.body.sem;
    const year=req.body.year
  getdet.find({
    sem : parseInt(sem),
   year : parseInt(year)
  }).then(result=>res.json(result)).catch(err=>{})
  
})
app.post('/faculty/createData',function(req,res){
  let json={
    sem:req.body.sem,
    year:req.body.year,
    students:req.body.students
  }
  let u=new getdet(json);
  u.save().then(()=>{
    res.send("success");
  }).catch(err=>{
    res.send(err);
  })
});
app.post('/faculty/getnos',function(req,res){
  const sem=req.body.sem;
  const year=req.body.year
getdet.find({
  sem : parseInt(sem),
 year : parseInt(year)
}).then(result=>res.json(result)).catch(err=>{})
});
app.post('/faculty/attendance',function(req,res){
  let json={
    sem:req.body.sem,
    year:req.body.year,
    period:req.body.period,
    subject:req.body.subject,
    date:req.body.date,
    absentees:req.body.absentees
  }
  let u=new attendance(json);
  u.save().then(()=>{
    res.send("success");
  }).catch(err=>{
    res.send(err);
  })
});


// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
